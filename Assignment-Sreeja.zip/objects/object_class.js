class university {
    constructor(name,recog,stream,number){
        this.name=name
        this.recog=recog
        this.stream=stream
        this.number=number
    }
}
var u1=new university("svu","svu","management","30000")
console.log(u1);