// numbers divisible by 7 

var num=50;
for(var i=0;i<=num;i++)
{
    if(i%7==0)
    {
        console.log(i);
    }
   
}