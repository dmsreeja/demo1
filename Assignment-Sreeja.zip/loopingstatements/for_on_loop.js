var array1=[1,2,3,4,5,6,7]
for (var value of array1) {
    value=value*10;
    console.log(value);
}