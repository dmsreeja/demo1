var a=10
console.log(typeof(a));

var b=true
console.log(typeof(b));

var c="message"
console.log(typeof(c));

var e='sd'
console.log(typeof(e));

var f
console.log(typeof(f));

var h=undefined
console.log(typeof(h));

var g=null
console.log(typeof(g));

console.log(x
    );