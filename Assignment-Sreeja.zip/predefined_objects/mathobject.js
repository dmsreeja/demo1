console.log(Math.PI);

console.log(Math.abs(-103)); //returns how far it is from 0

console.log(Math.max(23.8,23.9,23)); //returns maximum number

console.log(Math.min(12,-12,-89.9));

console.log(Math.random());

console.log(Math.ceil(8.01));

console.log(Math.floor(89.7));

console.log(Math.SQRT1_2);

console.log(Math.SQRT2);