var d=new Date()

console.log(d.getDate())
console.log(d.getDay());
console.log(d.getFullYear());
console.log(d.getMonth());
console.log(d.toDateString().split(" ")[1]);
//console.log();