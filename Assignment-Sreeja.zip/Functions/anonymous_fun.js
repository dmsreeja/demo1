(function (a,b) {
    console.log("sum of "+a+"and"+b+"is"+(a+b));
    })(45,-87) //this is immediate invocation
