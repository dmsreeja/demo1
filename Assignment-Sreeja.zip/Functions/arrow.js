// function sum(a,b) {
//     console.log(C:\Users\FCI1286\Desktop\javascript\Functions\arrow.js);
    
// }
// sum(4,7)

var arrow=() => console.log("this is an arrow function");
arrow()

var sum=(a,b) => {console.log((a+b));
    console.log(arguments);}
sum(12.3,45.6)
sum(9,9,8,9,8)