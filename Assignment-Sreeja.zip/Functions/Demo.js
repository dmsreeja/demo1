function demo() {
    console.log("this is a demo function");
    }
    demo()
    function parameterized(msg) {
        console.log(msg);
        
    }
    parameterized("parameterized")