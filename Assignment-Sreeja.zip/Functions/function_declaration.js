function avg(a,b) {
    console.log("sum of "+a+"and"+b+"is"+(a+b)/2);
    
}
avg(4,70)