// 

var div = function (a,b) {
    console.log("division result of "+a+"and"+b+"is"+(a/b));
    }
div(41,7)
div(13.4,3)
