var a=10;

if(a>0)
{
    console.log("a is positive");
}
